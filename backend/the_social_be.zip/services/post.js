const { db } = require("../models/post");
const Post = require("../models/post");

const getPosts = () => {
  return Post.find()
    .populate("author")
    .exec()
    .then((posts) => posts.map((post) => post._doc));
};

const createPost = (authorId, content, image) => {
  const newPost = new Post({ author: authorId, content, image });
  return newPost.save().then((newPost) => newPost._doc);
};

module.exports = { createPost, getPosts };
